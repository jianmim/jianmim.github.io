import{k as n,s as l,l as d,x as o,M as p,D as f,F as s,y as v,G as T,i as a,_ as r}from"./store-dof5ccn5.js";import{u as g}from"./index-xdJ7pE-g.js";import{_ as h}from"./_plugin-vue_export-helper-x3n3nnut.js";const x={class:"layout-navbars-container"},y=n({name:"layoutNavBars"}),C=n({...y,setup(V){const _=a(()=>r(()=>import("./index-ELJODXt1.js"),__vite__mapDeps([0,1,2,3,4,5,6]),import.meta.url)),c=a(()=>r(()=>import("./tagsView-qBo12T97.js"),__vite__mapDeps([7,1,2,3,4,5,8]),import.meta.url)),i=g(),{themeConfig:m}=l(i),u=d(()=>{let{layout:e,isTagsview:t}=m.value;return e!=="classic"&&t});return(e,t)=>(o(),p("div",x,[f(s(_)),u.value?(o(),v(s(c),{key:0})):T("",!0)]))}}),E=h(C,[["__scopeId","data-v-b9eeb2b2"]]);export{E as default};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./index-ELJODXt1.js","./store-dof5ccn5.js","../css/store-dzCp3yyn.css","./index-xdJ7pE-g.js","../css/index-5Z0pdBTT.css","./_plugin-vue_export-helper-x3n3nnut.js","../css/index-8NvNvBTl.css","./tagsView-qBo12T97.js","../css/tagsView-IUhTXd0Q.css"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}

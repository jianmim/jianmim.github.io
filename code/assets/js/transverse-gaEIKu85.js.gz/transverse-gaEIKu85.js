import{k as c,r as y,s as T,u as v,p as R,w as a,n,t as h,x as C,y as k,A as x,D as r,F as s,i as l,_ as u}from"./store-dof5ccn5.js";import{u as M}from"./index-zQlakb1H.js";const g=c({name:"layoutTransverse"}),S=c({...g,setup(w){const i=l(()=>u(()=>import("./header-JT3xuPnN.js"),__vite__mapDeps([0,1,2,3,4]),import.meta.url)),_=l(()=>u(()=>import("./main-w_M2wn_I.js"),__vite__mapDeps([5,1,2,3,4]),import.meta.url)),e=y(),p=M(),{themeConfig:f}=T(p),m=v(),t=()=>{e.value.layoutMainScrollbarRef.update()},o=()=>{n(()=>{setTimeout(()=>{t(),e.value.layoutMainScrollbarRef.wrapRef.scrollTop=0},500)})};return R(()=>{o()}),a(()=>m.path,()=>{o()}),a(()=>f.value.isTagsview,()=>{n(()=>{t()})},{deep:!0}),(b,A)=>{const d=h("el-container");return C(),k(d,{class:"layout-container flex-center layout-backtop"},{default:x(()=>[r(s(i)),r(s(_),{ref_key:"layoutMainRef",ref:e},null,512)]),_:1})}}});export{S as default};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./header-JT3xuPnN.js","./store-dof5ccn5.js","../css/store-dzCp3yyn.css","./index-zQlakb1H.js","../css/index-5Z0pdBTT.css","./main-w_M2wn_I.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
